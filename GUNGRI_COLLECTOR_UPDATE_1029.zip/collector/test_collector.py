"""python -m unittest collector.test_collector"""
import json, os, tempfile, unittest, datetime
from . import mapping, run
from .tourapi import TourAPI, TourAPIError, QuotaExceeded


class T(unittest.TestCase):
    def run_mock(self, out, *extra):
        self.assertEqual(run.main(['--mock', '--out', out] + list(extra)), 0)
        return json.load(open(os.path.join(out, 'gungri_feed.json'), encoding='utf-8'))

    def test_feed_shape_and_rules(self):
        with tempfile.TemporaryDirectory() as d:
            f = self.run_mock(d)
            self.assertEqual(f['schema'], 'GUNGRI_FEED_V1')
            names = [p['n'] for p in f['places']]
            self.assertIn('국립현대미술관 청주', names)
            self.assertFalse(any('키즈' in n for n in names), '제외 키워드')
            self.assertEqual([e['name'] for e in f['events']], ['구리 코스모스 축제'], '끝난 행사 제외')
            p = next(x for x in f['places'] if x['n'] == '국립현대미술관 청주')
            self.assertEqual(p['hours'], '10:00~18:00 / (입장마감 17:00)')
            self.assertEqual(p['ar'], '충청')
            self.assertTrue(p['sourceUrl'].startswith('https://'))
            self.assertTrue(all(ph['url'].startswith('https://') for ph in p['photos']))
            mk = next(x for x in f['places'] if x['n'] == '구리전통시장')
            self.assertFalse(mk['photos'][0]['usable'], '저작권 유형 없는 사진은 사용 불가')
            self.assertNotIn('fee', mk, '없는 값은 넣지 않음')

    def test_local_keyword_and_commercial_filter(self):
        with tempfile.TemporaryDirectory() as d:
            f = self.run_mock(d)
            names = [p['n'] for p in f['places']]
            self.assertIn('속초 ○○유원지', names, '지방 유원지(키워드 검색)')
            self.assertIn('청주 ○○ 먹자골목', names, '지방 먹자골목(음식점 유형이라도 골목·거리형은 받음)')
            self.assertIn('스마트팜 체험관', names, '“스마트”는 마트로 오인하지 않음')
            self.assertFalse(any('아울렛' in n or '홈플러스' in n for n in names), '백화점·마트·아울렛 등 상업시설 제외')
            self.assertNotIn('○○식당 본점', names, '개별 식당은 받지 않음')
            ar = {p['n']: p['ar'] for p in f['places']}
            self.assertEqual(ar['속초 ○○유원지'], '강원')
            u = next(x for x in f['places'] if x['n'] == '속초 ○○유원지')
            self.assertEqual(u['coordState'], 'SOURCE_PROVIDED'); self.assertAlmostEqual(u['lat'], 38.20)

    def test_local_first_when_budget_small(self):
        with tempfile.TemporaryDirectory() as d:
            f = self.run_mock(d, '--max-details', '3')
            got = [p['ar'] for p in f['places']]
            self.assertTrue(all(a in ('강원', '충청') for a in got), '하루 상한이 작으면 지방(키워드 적중)을 먼저 받음: %s' % got)

    def test_mountain_and_trail(self):
        with tempfile.TemporaryDirectory() as d:
            f = self.run_mock(d)
            names = [p['n'] for p in f['places']]
            self.assertIn('가리산 자연휴양림', names, '100대 명산 이름 검색(10개씩)')
            self.assertNotIn('가리산 횟집', names); self.assertNotIn('가리산 약수터', names, '다른 지역·음식점은 받지 않음')
            self.assertIn('○○ 둘레길', names)
            st = json.load(open(os.path.join(d, 'state.json'), encoding='utf-8'))
            self.assertEqual(st['nameCursor']['mountain100'], 10, '다음 날은 11번째 산부터')
            self.run_mock(d)
            st = json.load(open(os.path.join(d, 'state.json'), encoding='utf-8'))
            self.assertEqual(st['nameCursor']['mountain100'], 20)
        L = json.load(open(os.path.join(run.HERE, 'curation', 'mountain100.json'), encoding='utf-8'))
        self.assertEqual(len(L['items']), 100)
        rec = [{'n': '설악산국립공원', 'ar': '강원'}, {'n': '경주 남산', 'ar': '경북'}, {'n': '서울 남산', 'ar': '서울'}, {'n': '남산타워', 'ar': '서울'}]
        run.curation_tag(rec)
        self.assertIn('산림청 100대 명산', rec[0].get('curation', [])); self.assertIn('산림청 100대 명산', rec[1].get('curation', []))
        self.assertNotIn('curation', rec[2]); self.assertNotIn('curation', rec[3])

    def test_shop_ok_and_regex(self):
        cfg = run.load(os.path.join(run.HERE, 'config.json'), {})
        for ttl in ('롯데백화점 광주점', '○○ 이마트', '스타필드 안성', '○○ 매장', '동네마트', '프리미엄 아울렛'):
            self.assertTrue(run.excluded(ttl, cfg), ttl)
        for ttl in ('스마트팜 체험관', '매장문화재 전시관', '부평깡통시장', '속초중앙시장'):
            self.assertFalse(run.excluded(ttl, cfg), ttl)
        self.assertTrue(run.shop_ok('죽도시장', '38', cfg)); self.assertFalse(run.shop_ok('○○ 쇼핑센터점', '38', cfg)); self.assertTrue(run.shop_ok('○○백화점', '12', cfg))
        self.assertEqual(len(cfg['regions']), 17)

    def test_medical_and_department_store(self):
        cfg = run.load(os.path.join(run.HERE, 'config.json'), {})
        for ttl, addr in (('구리중앙병원', ''), ('행복약국', ''), ('밝은안경원', ''), ('서울치과의원', ''), ('구리시보건소', ''), ('성모요양병원', ''),
                          ('롯데시네마 건대', ''), ('○○카페', '서울 중구 소공로 롯데백화점 본점 1층'), ('스타벅스', '경기 판교 현대백화점 판교점'), ('○○식당', '경기 구리 이마트 구리점 1층')):
            self.assertTrue(run.excluded(ttl, cfg, addr), ttl + ' ' + addr)
        for ttl, addr in (('대구안경박물관', ''), ('서울한방진흥센터', ''), ('구리전통시장', '경기 구리시 구리시장로 19'), ('한강공원', ''), ('남이섬', ''), ('국립현대미술관 청주', '')):
            self.assertFalse(run.excluded(ttl, cfg, addr), ttl)

    def test_medical_not_in_feed_and_old_feed_cleaned(self):
        with tempfile.TemporaryDirectory() as d:
            f = self.run_mock(d)
            names = [p['n'] for p in f['places']]
            for bad in ('구리중앙병원', '행복약국', '밝은안경원', '○○카페'):
                self.assertNotIn(bad, names)
            old = json.load(open(os.path.join(d, 'gungri_feed.json'), encoding='utf-8'))
            old['places'].append({'feedId': 'TA-777', 'n': '옛 약국', 'a': '경기 구리시'}); old['places'].append({'feedId': 'TA-778', 'n': '카페', 'a': '서울 롯데백화점 본점'})
            json.dump(old, open(os.path.join(d, 'gungri_feed.json'), 'w', encoding='utf-8'), ensure_ascii=False)
            f2 = self.run_mock(d)
            ids = [p['feedId'] for p in f2['places']]
            self.assertNotIn('TA-777', ids); self.assertNotIn('TA-778', ids)

    def test_incremental(self):
        with tempfile.TemporaryDirectory() as d:
            self.run_mock(d)
            self.run_mock(d)  # 수도권(후순위)에서 건너뛴 항목은 이튿날 이어서 받음
            f = self.run_mock(d)
            self.assertEqual(f['stats']['newPlaces'], 0)
            self.assertEqual(f['stats']['places'], 11, '이전 피드 유지')

    def test_budget(self):
        with tempfile.TemporaryDirectory() as d:
            f = self.run_mock(d, '--max-details', '2')
            self.assertEqual(f['stats']['newPlaces'] + f['stats']['newEvents'], 2)

    def test_order_events_first_then_mixed_regions(self):
        with tempfile.TemporaryDirectory() as d:
            f = self.run_mock(d, '--max-details', '3')
            self.assertEqual(f['stats']['newEvents'], 1, '행사를 먼저 받음')
            self.assertEqual(len({p['ar'] for p in f['places']}), 2, '장소는 권역을 번갈아 받음')

    def test_region_filter_and_photo_cap(self):
        from . import mock
        mock.FESTIVALS.append({'contentid': '900103', 'title': '부산 바다축제', 'addr1': '부산광역시 해운대구', 'lDongRegnCd': '26', 'eventstartdate': mock.D(5), 'eventenddate': mock.D(9), 'modifiedtime': '20260925090000'})
        mock.COMMON['900103'] = {'overview': '부산 행사', 'firstimage': '', 'cpyrhtDivCd': ''}
        try:
            with tempfile.TemporaryDirectory() as d:
                self.assertEqual(run.main(['--mock', '--out', d]), 0)
                f = json.load(open(os.path.join(d, 'gungri_feed.json'), encoding='utf-8'))
                self.assertEqual([e['name'] for e in f['events']], ['구리 코스모스 축제'], '권역 밖 행사 제외')
            cfg = {'maxPhotos': 2}
            rec = [{'photos': [{'usable': False}, {'usable': True, 'u': 1}, {'usable': True, 'u': 2}]}]
            run.slim(rec, cfg)
            self.assertEqual([p.get('u') for p in rec[0]['photos']], [1, 2], '사용 가능한 사진 우선 · 최대 장수')
        finally:
            mock.FESTIVALS[:] = [x for x in mock.FESTIVALS if x['contentid'] != '900103']

    def test_exclude_ids(self):
        with tempfile.TemporaryDirectory() as d:
            f = self.run_mock(d)
            pid = f['places'][0]['feedId']; eid = f['events'][0]['feedId']
            ex = os.path.join(os.path.dirname(run.__file__), 'exclude.json')
            old = open(ex, encoding='utf-8').read()
            try:
                open(ex, 'w', encoding='utf-8').write(json.dumps({'excludeIds': [pid, eid]}))
                f2 = self.run_mock(d)
                self.assertNotIn(pid, [x['feedId'] for x in f2['places']], '폐기한 장소는 피드에서 빠짐')
                self.assertNotIn(eid, [x['feedId'] for x in f2['events']], '폐기한 행사는 피드에서 빠짐')
            finally:
                open(ex, 'w', encoding='utf-8').write(old)

    def test_timeout_is_retried_not_fatal(self):
        n = {'c': 0}
        def flaky(u):
            n['c'] += 1
            if n['c'] < 3: raise TimeoutError('The read operation timed out')
            return '{"response":{"header":{"resultCode":"0000"},"body":{"items":"","totalCount":0}}}'
        api = TourAPI('K', opener=flaky, sleep=0)
        import time as _t; old = _t.sleep; _t.sleep = lambda x: None
        try:
            self.assertEqual(api.call('x')['items'], [])
            def dead(u): raise TimeoutError('t')
            api2 = TourAPI('K', opener=dead, sleep=0)
            self.assertRaises(TourAPIError, api2.call, 'x')
        finally:
            _t.sleep = old

    def test_errors(self):
        self.assertRaises(TourAPIError, TourAPI, '')
        api = TourAPI('K', opener=lambda u: '<OpenAPI_ServiceResponse><cmmMsgHeader><returnAuthMsg>SERVICE_KEY_IS_NOT_REGISTERED_ERROR</returnAuthMsg></cmmMsgHeader></OpenAPI_ServiceResponse>', sleep=0)
        with self.assertRaisesRegex(TourAPIError, 'SERVICE_KEY_IS_NOT_REGISTERED'):
            api.call('areaBasedList2')
        api = TourAPI('K', budget=1, opener=lambda u: '{"response":{"header":{"resultCode":"0000"},"body":{"items":"","totalCount":0}}}', sleep=0)
        self.assertEqual(api.call('x')['items'], [])
        self.assertRaises(QuotaExceeded, api.call, 'x')

    def test_key_encoding(self):
        a = TourAPI('abc+/=', sleep=0); self.assertIn('serviceKey=abc%2B%2F%3D', a._url('op', {}))
        b = TourAPI('abc%2B', sleep=0); self.assertIn('serviceKey=abc%2B&', b._url('op', {}))

    def test_curation_tag(self):
        recs = [{'name': '2026 진주남강유등축제'}, {'n': '서울숲'}]
        self.assertEqual(run.curation_tag(recs), 1)
        self.assertEqual(recs[0]['curation'], ['로컬100'])

    def test_photo_rights_and_options(self):
        recs = [{'n': 'a', 'photos': [
            {'url': 'u1', 'usable': True, 'license': '공공누리 1유형'},
            {'url': 'u2', 'usable': True, 'license': '공공누리 3유형'},
            {'url': 'u3', 'usable': True, 'license': '공공누리 1유형', 'rights': 'AUTO'},
            {'url': 'u4', 'usable': False, 'license': '공공누리 4유형'}]}]
        n = run.apply_photo_rights(recs, {'u3'}, {'u4'})
        self.assertEqual(n, 1)
        ph = recs[0]['photos']
        self.assertEqual([x['url'] for x in ph], ['u1', 'u2', 'u4'])
        self.assertEqual(ph[0]['rights'], 'AUTO')
        self.assertEqual(ph[1]['rights'], 'AUTO_NOEDIT')
        self.assertFalse(ph[2].get('rights'))
        with tempfile.TemporaryDirectory() as d:
            f = self.run_mock(d)
            self.assertTrue(f['options']['showExamples'])

    def test_taxonomy_sub(self):
        from . import taxonomy
        self.assertEqual(taxonomy.sub_of_place('국립현대미술관 서울', ['문화/미술관']), '미술관')
        self.assertEqual(taxonomy.sub_of_place('망원시장', ['시장']), '시장')
        self.assertEqual(taxonomy.sub_of_place('성심당', []), '맛집')
        self.assertEqual(taxonomy.sub_of_event('고양호수예술축제', ['공연']), '축제')
        self.assertEqual(taxonomy.sub_of_event('한강 걷기 대회', []), '행사')
        with tempfile.TemporaryDirectory() as d:
            f = self.run_mock(d)
            self.assertTrue(all(p.get('sub') is None or isinstance(p['sub'], str) for p in f['places']))
            self.assertTrue(all(e.get('sub') for e in f['events']), '행사는 세부 유형이 항상 붙음')

    def test_clean(self):
        self.assertEqual(mapping.clean('a<br>b &amp; c'), 'a / b & c')
        self.assertEqual(mapping.href('<a href="https://x.kr/y">x</a>'), 'https://x.kr/y')


if __name__ == '__main__':
    unittest.main()
