궁리 서버 설정 안내 (앱 쪽 코드는 이미 들어 있고, 아래 서버 설정을 켜야 실제로 작동합니다)

A. 관리자 알림 (캡틴 신청 · 새 회원)
 1) Supabase > SQL Editor 에서 01_captain_applications.sql 실행 (파일 안 YOUR-PROJECT, CHANGE_ME_SECRET 수정)
 2) 텔레그램에서 @BotFather 로 봇을 만들고 토큰을 받은 뒤, 봇과 대화를 시작해 chat_id 확인
 3) Supabase CLI: supabase functions deploy notify-admin --no-verify-jwt
    supabase secrets set HOOK_SECRET=... TELEGRAM_BOT_TOKEN=... TELEGRAM_CHAT_ID=...
 4) 캡틴 신청을 한 번 넣어 보고 텔레그램에 오는지 확인
 ※ 로그인한 상태에서 낸 신청서만 서버에 올라갑니다. 서버에 올라간 신청서는 관리자 기기에서 20초마다 승인 대기 목록으로 불러옵니다.

B. 문자 인증 (비밀번호 찾기, 가입 인증)
 1) Supabase > Authentication > Providers > Phone 켜기
 2) 국내 문자: Authentication > Hooks > Send SMS 에 send-sms 함수 연결 (솔라피 가입·발신번호 등록 필요, 문자 1건당 약 10원대)
    supabase functions deploy send-sms --no-verify-jwt  /  secrets: SOLAPI_KEY, SOLAPI_SECRET, SOLAPI_FROM
 3) 확인: 앱 로그인 창 > "비밀번호를 잊으셨나요?" > 내 번호 입력 > 문자 수신
 ※ 이 설정 전에는 "문자를 보내지 못했어요" 라고 표시됩니다. 이메일(운영진)은 기본 메일로 바로 됩니다.
