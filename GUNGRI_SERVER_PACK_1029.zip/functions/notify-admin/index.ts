// Supabase Edge Function: 가입·캡틴 신청이 생기면 텔레그램(및 선택: 이메일)으로 알림
// 환경변수(Secrets): HOOK_SECRET, TELEGRAM_BOT_TOKEN, TELEGRAM_CHAT_ID
Deno.serve(async (req) => {
  if (req.headers.get("x-hook-secret") !== Deno.env.get("HOOK_SECRET")) return new Response("no", { status: 401 });
  const { table, record } = await req.json();
  let text = "";
  if (table === "captain_applications") {
    text = `🧭 [궁리] 캡틴 신청\n이름: ${record.name}\n지역: ${record.region}\n연락처: ${record.tel}\n→ 앱 관리자 화면에서 확인·승인하세요.`;
  } else if (table === "profiles") {
    text = `🙋 [궁리] 새 회원 가입\n별명: ${record.nickname ?? "-"}\n지역: ${record.sido ?? ""} ${record.sigungu ?? ""}`;
  } else return new Response("skip");
  const r = await fetch(`https://api.telegram.org/bot${Deno.env.get("TELEGRAM_BOT_TOKEN")}/sendMessage`, {
    method: "POST", headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ chat_id: Deno.env.get("TELEGRAM_CHAT_ID"), text }),
  });
  return new Response(r.ok ? "ok" : "fail", { status: r.ok ? 200 : 502 });
});
