// Supabase "Send SMS Hook" → 솔라피(Solapi) 문자 발송 (국내 번호 인증용)
// Auth > Hooks > Send SMS > HTTPS 로 이 함수 주소를 연결. 환경변수: SOLAPI_KEY, SOLAPI_SECRET, SOLAPI_FROM(등록된 발신번호)
import { createHmac } from "node:crypto";
Deno.serve(async (req) => {
  const { user, sms } = await req.json();
  const to = String(user.phone).replace(/^\+?82/, "0");
  const date = new Date().toISOString(), salt = crypto.randomUUID().replace(/-/g, "");
  const sig = createHmac("sha256", Deno.env.get("SOLAPI_SECRET")!).update(date + salt).digest("hex");
  const r = await fetch("https://api.solapi.com/messages/v4/send", {
    method: "POST",
    headers: { "Content-Type": "application/json", Authorization: `HMAC-SHA256 apiKey=${Deno.env.get("SOLAPI_KEY")}, date=${date}, salt=${salt}, signature=${sig}` },
    body: JSON.stringify({ message: { to, from: Deno.env.get("SOLAPI_FROM"), text: `[궁리] 인증번호 ${sms.otp} (5분 안에 입력)` } }),
  });
  return r.ok ? new Response("{}", { headers: { "Content-Type": "application/json" } })
              : new Response(JSON.stringify({ error: { http_code: 500, message: "sms failed" } }), { status: 500 });
});
