-- 궁리 캡틴 신청서 서버 저장 + 관리자 알림 (Supabase SQL Editor에서 한 번 실행)
create extension if not exists pg_net;

create table if not exists public.captain_applications(
  id uuid primary key default gen_random_uuid(),
  applicant_uid uuid not null,
  name text, born int, region text, tel text,
  payload jsonb default '{}'::jsonb,
  status text not null default 'SUBMITTED',  -- SUBMITTED / STAFF_REVIEWED / APPROVED / REJECTED
  reason text, reviewed_by uuid,
  created_at timestamptz default now(), updated_at timestamptz default now()
);
alter table public.captain_applications enable row level security;

-- 신청자: 본인 것만 넣기·보기 / 운영진(staff_roles에 있는 사람): 전체 보기·상태 변경
create policy cap_ins on public.captain_applications for insert to authenticated
  with check (applicant_uid = auth.uid() and status = 'SUBMITTED');
create policy cap_sel_own on public.captain_applications for select to authenticated
  using (applicant_uid = auth.uid());
create policy cap_sel_staff on public.captain_applications for select to authenticated
  using (exists(select 1 from public.staff_roles s where s.user_id = auth.uid()));
create policy cap_upd_staff on public.captain_applications for update to authenticated
  using (exists(select 1 from public.staff_roles s where s.user_id = auth.uid()));

-- 알림 대상 테이블 → Edge Function(notify-admin) 호출
-- ※ 아래 두 값을 본인 것으로 바꾸세요: 프로젝트 주소, 비밀 토큰(아무 긴 문자열, 함수 환경변수 HOOK_SECRET과 동일)
create or replace function public.notify_admin() returns trigger language plpgsql security definer as $$
begin
  perform net.http_post(
    url := 'https://YOUR-PROJECT.supabase.co/functions/v1/notify-admin',
    headers := jsonb_build_object('Content-Type','application/json','x-hook-secret','CHANGE_ME_SECRET'),
    body := jsonb_build_object('table', TG_TABLE_NAME, 'type', TG_OP, 'record', to_jsonb(NEW))
  );
  return NEW;
end $$;

drop trigger if exists trg_notify_cap on public.captain_applications;
create trigger trg_notify_cap after insert on public.captain_applications
  for each row execute function public.notify_admin();

-- 일반 회원 가입 알림 (profiles에 행이 생길 때)
drop trigger if exists trg_notify_profile on public.profiles;
create trigger trg_notify_profile after insert on public.profiles
  for each row execute function public.notify_admin();
-- staff_roles 컬럼명이 user_id가 아니면 위 cap_sel_staff / cap_upd_staff 의 s.user_id 를 실제 컬럼명으로 고치세요.
